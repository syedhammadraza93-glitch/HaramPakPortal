import { Router } from "express";
import {
  addAgencyNote, changeAgencyStatus, downloadAgencyDocument, getAgency, listAgencies,
  resendAgencyVerification, unlockAgencyUser, updateAgency, verifyAgencyDocument,
} from "../controllers/adminAgency.controller";
import { jwtGuard, requirePermission as can } from "../middleware/auth.middleware";
import { asyncHandler as h } from "../utils/http";

const router = Router();
router.use(jwtGuard);


router.get("/agencies", can("agent.view"), h(listAgencies));
router.get("/agencies/:id", can("agent.view"), h(getAgency));
router.patch("/agencies/:id", can("agent.edit"), h(updateAgency));
// approve | reject | request-info | suspend | reactivate | deactivate | reopen (permission checked per action)
router.post("/agencies/:id/status/:action", can("agent.view"), h(changeAgencyStatus));
router.post("/agencies/:id/notes", can("agent.notes"), h(addAgencyNote));
router.post("/agencies/:id/resend-verification", can("agent.approve"), h(resendAgencyVerification));
router.post("/agencies/:id/users/:userId/unlock", can("agent.edit"), h(unlockAgencyUser));
router.get("/agencies/:id/documents/:documentId", can("agent.view"), h(downloadAgencyDocument));
router.patch("/agencies/:id/documents/:documentId", can("agent.approve"), h(verifyAgencyDocument));

export default router;
